Game("Home"){
  Name="Home";
  Desc="This is where you can change your name or load character.";
  Map="Home";
  MaxPC=8;
  MaxNPC=0;
  GameFlags="CanChangeName"|"Multiplayer";
}
Game("BloodThrist"){
  Name="Night of the walking deads";
  Desc="All you can kill skeletons! Use /npcmax(num) and /pcmax(num) to change the settings.";
  Map="Arena2";
  MaxPC=1;
  MaxNPC=32;NumNPC=16;
  GameFlags="TestZone";
}
Game("TestZone"){
  Name="TestZone";
  Desc="TestZone.";
  Map="Arena2";
  Trigger="TestZone";
  MaxPC=1;
  MaxNPC=2;NumNPC=2;
  GameFlags="FixedSettings";
}
Game("Arena"){
  Name="Arena";
  Desc="Try your skills in this free for all arena! Use /npcmax(num) and /pcmax(num) to change the settings.";
  Map="Arena";
  MaxPC=8;
  MaxNPC=8;NumNPC=2;
  GameFlags="Multiplayer";
}
Game("Training"){
  Name="Training";
  Desc="Basic training with the warden.";
  Map="Floating Platforms";
  Trigger="Training";
  MaxPC=1;
  MaxNPC=1;
  NumNPC=1;
  GameFlags="FixedSettings"|"SoulEater";
}
Game("Diary"){
  Name="Mary's Diary";
  Desc="Retreive Mary's precious diary from her evil brothers! Note: Both Timmy and Billy must be dead at the same time to beat the game.";
  Map="Arena";
  Trigger="Diary";
  MaxPC=1;
  MaxNPC=3;
  NumNPC=3;
  GameFlags="FixedSettings"|"SoulEater";
}
Game("Riot Control"){
  Name="Riot Control";
  Desc="The warden has told you to take his place while he's off for an emergency. Defeat as many enemies as possible within 5 minutes!";
  Map="Arena";
  Trigger="Riot Control";
  MaxPC=2;
  MaxNPC=3;
  NumNPC=3;
  GameFlags="FixedSettings"|"Multiplayer"|"MultiplayerPause";
}
Game("Boneville"){
  Name="Boneville";
  Desc="Welcome to Boneville!";
  Map="Boneville";
  Trigger="Boneville";
  MaxPC=8;
  MaxNPC=7;
  NumNPC=7;
  GameFlags="FixedSettings"|"Multiplayer";
}
