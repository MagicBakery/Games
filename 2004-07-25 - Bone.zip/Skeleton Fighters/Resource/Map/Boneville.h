Map("Boneville"){
  Bound(<0,-40,0>,<200,0,200>,3);
  Tile(<-4.00,0.00,4.00>,"Platform 16x16","Ground",1);
  Tile(<16.00,-10.00,0.00>,"Platform 8x8","Ground",5);
  Tile(<-2.00,-1.00,-5.00>,"Platform 2x2","Ground",1);
  Tile(<0.00,-2.00,-6.00>,"Platform 2x2","Ground",1);
  Tile(<2.00,-3.00,-7.00>,"Platform 2x2","Ground",1);
  Tile(<4.00,-4.00,-8.00>,"Platform 2x2","Ground",1);
  Tile(<6.00,-5.00,-8.5>,"Platform 2x2","Ground",1);
  Tile(<8.00,-6.00,-8.00>,"Platform 2x2","Ground",1);
  Tile(<10.00,-7.00,-7.00>,"Platform 2x2","Ground",1);
  Tile(<12.00,-8.00,-6.00>,"Platform 2x2","Ground",1);
  Tile(<14.00,-9.00,-5.00>,"Platform 2x2","Ground",1);
  Tile(<-18.00,-30.00,-5.00>,"Platform 2x2","Ground",1);
  Tile(<-22.00,-30.00,-6.00>,"Platform 2x2","Ground",1);
  Tile(<-26.00,-30.00,-7.00>,"Platform 2x2","Ground",1);
  Tile(<-27.00,-29.00,-5.00>,"Platform 2x2","Ground",1);
  Tile(<-30.00,-29.00,-8.00>,"Platform 2x2","Ground",1);
  Tile(<-33.00,-29.00,-8.00>,"Platform 1x1","Ground",1);
  Tile(<-36.00,-29.00,-7.00>,"Platform 1x1","Ground",1);
  Tile(<-39.00,-29.00,-6.00>,"Platform 1x1","Ground",1);
  Tile(<-42.00,-29.00,-5.00>,"Platform 1x1","Ground",1);
  Tile(<-45.00,-29.00,-2.00>,"Platform 4x4","Ground",1);

  Item("Great Sword",<-46,-28,-1>,<-1.57,0.7,0>);
}
