Map("Home"){
  Bound(<0,-20,0>,<100,0,100>,3);
  Tile(<0.00,0.00,0.00>,"Platform 8x8","Ground",5);
  Tile(<5.00,0.0,2.00>,"Platform 2x2","Ground",5);
  Tile(<7.00,0.00,2.00>,"Platform 2x2","Ground",5);
  Tile(<9.5,0.0,2.00>,"Platform 4x4","Ground",5);
  Tile(<9.5,-8,2.00>,"Platform 8x8","Ground",5);
  Tile(<9.5,-9,-4>,"Platform 2x2","Ground",5);
  Tile(<9.5,-10,-7>,"Platform 2x2","Ground",5);
  Tile(<9.5,-11,-13>,"Platform 8x8","Ground",5);

  Item("Sword",<0,0,-1>,<0,0.7,-1.57>);
  Item("Great Sword",<1,1,-1>,<-1.57,0.7,0>);
  Item("Shield",<0,0,-2>,<0.2,0.3,0>);
  Item("Great Katana",<-2,0.6,-1>,<-1.57,0.7,0>);
  Item("Katana",<-1.5,0.3,-1>,<-1.57,0.7,0>);
}
