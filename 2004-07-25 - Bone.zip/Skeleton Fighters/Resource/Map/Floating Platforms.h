Map("Floating Platforms"){
  Bound(<0.00,-10.00,0.00>,<100.00,0.00,100.00>,3);
  Tile(<4.00,-1.00,0.00>,"Platform 2x2","Dirt",1);
  Tile(<6.00,-2.00,2.00>,"Platform 2x2","Dirt",1);
  Tile(<8.00,-1.00,2.00>,"Platform 1x1","Dirt",1);
  Tile(<10.00,0.00,1.00>,"Platform 1x1","Dirt",1);
  Tile(<12.00,-1.00,2.00>,"Platform 2x2","Dirt",1);
  Tile(<14.00,0.00,0.00>,"Platform 2x2","Dirt",1);
  Tile(<0.00,0.00,0.00>,"Platform 4x4","Dirt",1);
  Tile(<16.00,0.00,-3.00>,"Platform 2x2","Dirt",1);
  Tile(<15.00,1.00,-6.00>,"Platform 1x1","Dirt",1);
  Tile(<17.00,1.00,-9.00>,"Platform 4x4","Dirt",1);
  Tile(<7.00,-2.00,-8.00>,"Platform 8x8","Dirt",5);
  Tile(<15.00,-1.00,-15.00>,"Platform 4x4","Dirt",1);
  Tile(<11.00,0.00,-15.00>,"Platform 2x2","Dirt",1);
}
