Trigger("Initialization"){
  Condition = "True";

  EffectBegin{

    NPC("Warden"){
      CharModel = "Warden";
      Pos = <3,0,3>;
      MGAvailable = "ALL";
      AI = "Wander"|"Revenge"|"TileBound"|"Help";
      Equip("Shield");
      Equip("Sword");
      RespawnPolicy = "OnSpot";
      
      AgentTrigger("FSM"){
        Condition="Clicked";
        EffectBegin{
          CSN_Clear();
          FSM(0){
            CSN_SuspendAI();
            CSN_ActorPrompt("Want to duel, kido?");
            CSN_Choice(1,"No, wait...");
            CSN_Choice(2,"Yes, bring it on!");
            CSN_ResumeAI();
          }
          FSM(1){
            CSN_SuspendAI();
            CSN_PlayerTellActor("Maybe next time...");
            CSN_ResumeAI();
            FSM_State=0;
          }
          FSM(2){
            CSN_SuspendAI();
            CSN_PlayerTellActor("Bring it on!");
            CSN_ActorTellPlayer("Ready when you are!");CSN_Timer=2;
            CSN_ResumeAI();
            Say("Ready when you are!");
            FSM_State=0;
          }
       
          
          SCM("Cutscene");
        }EndEffect; 
      }
    }
  
    
    NPC("Mary"){
      CharModel="Warden";
      Pos=<-3,0,3>;
      MGAvailable="ALL";
      AI="Flee"|"TileBound"|"CallForHelp"|"Help";
      RespawnPolicy="OnSpot";

      AgentTrigger("FSM"){
        Condition="Clicked";
        EffectBegin{
          CSN_Clear();

          FSM(0){
            CSN_ActorTellPlayer("hihi!");
            CSN_ActorPrompt("Do you like my dress?");
            CSN_Choice(2,"What?!...what dress...?");
            CSN_Choice(1,"Yea, it is gorgeous!");
          }
          FSM(1){
            CSN_PlayerTellActor("Yea, It is gorgeous, I like it!");
            CSN_ActorTellPlayer("ooo you are so sweet!");
            FSM_State=3;
          }
          FSM(2){
            CSN_PlayerTellActor("Um...what dress...?");
            CSN_ActorTellPlayer("You are boring.");
            FSM_State=3;
          }
          
          SCM("Cutscene");
          
        }EndEffect; 
      }
      AgentTrigger("Attacked"){
        Condition="Attacked";
        EffectBegin{
          Say("Help! PKer!");
          FSM_State=3;
          RemoveThisTrigger();
        }EndEffect; 
      }
    }

    NPC("Billy"){
      CharModel = "Player";
      Pos = <-3,0,-2>;
      MGAvailable = "ALL";
      AI = "Wander"|"Skirmish"|"TileBound"|"Jump"|"CallForHelp";
      RespawnPolicy = "OnSpot";

      AgentTrigger("FSM"){
        Condition="Clicked";
        EffectBegin{
          CSN_Clear();
        
          FSM(0){
            CSN_SuspendAI();
            CSN_ActorPrompt("Hey, want to do something fun?");
            CSN_Choice(1,"No, I know what you are up to.");
            CSN_Choice(2,"Like what...?");
            CSN_ResumeAI();
          }
          FSM(1){
            CSN_SuspendAI();
            CSN_PlayerTellActor("No, I know what you are up to.");
            CSN_ActorTellPlayer("No you don't!");
            CSN_PlayerTellActor("Of course I do.");
            CSN_PlayerPrompt("Of course I do.");
            CSN_Choice(3,"You are going to show me a secret place.");
            CSN_Choice(4,"You are going to steal Mary's diary");
            CSN_ResumeAI();
          }
          FSM(2){
            CSN_SuspendAI();
            CSN_PlayerTellActor("Like what...?");
            CSN_Delay(1);
            CSN_ActorTellPlayer("I found a Secret place!");
            CSN_PlayerTellActor("Oh? Where?");
            CSN_Delay(1);
            CSN_ActorTellPlayer("...actually, I don't want to tell you...");
            CSN_ResumeAI();
            FSM_State=5;
          }
          FSM(3){
            CSN_SuspendAI();
            CSN_PlayerTellActor("You are going to show me a secret place.");
            CSN_ActorTellPlayer("Weird...how do you know...");
            CSN_Delay(1);
            CSN_ActorTellPlayer("Bet you don't know where it is though...");
            CSN_PlayerTellActor("Well where is it?");
            CSN_Delay(1);
            CSN_ActorTellPlayer("Not gonna tell you!");
            CSN_PlayerTellActor("Come on!");
            CSN_ResumeAI();
            FSM_State=5;
          }
          FSM(4){
            CSN_SuspendAI();
            CSN_PlayerTellActor("You are going to steal your sister's diary.");
            CSN_ActorTellPlayer("LOL, see! You don't know!");CSN_Action="Laugh";
            CSN_PlayerTellActor("What then...?");
            CSN_ActorTellPlayer("I found a Secret place!");
            CSN_PlayerTellActor("Where?");
            CSN_ActorTellPlayer("...actually, I don't want to tell you...");
            CSN_ResumeAI();
            FSM_State=5;
          }
          FSM(5){
            Say("Not telling...");
          }
          FSM(6){
            CSN_SuspendAI();
            CSN_PlayerTellActor("Now, tell me, or I will kick your ass again!");
            CSN_ActorTellPlayer("ok...I'll tell you...");
            CSN_Delay(1);
            CSN_ActorTellPlayer("The other day when I was jumping around,");
            CSN_ActorTellPlayer("I fell off to a platform.");
            CSN_PlayerTellActor("Yea, you fell off to the jail cell.");
            CSN_ActorTellPlayer("No, not there. There was no stairs or anything.");
            CSN_PlayerTellActor("What did you find there?");
            CSN_ActorTellPlayer("Well, there were many small platforms...");
            CSN_ActorTellPlayer("I couldn't get to the end, but I am sure that is something cool!");
            CSN_PlayerThink("hmm...");
            CSN_PlayerTellActor("Where did you fell off from?");
            CSN_ActorTellPlayer("This is the interesting part...");
            CSN_ActorTellPlayer("I don't remember. That is why I was trying to see whether you want to find out with me.");
            CSN_ActorPrompt("Want to find it?");
            CSN_Choice(7,"No, you are trying to trick me!");
            CSN_Choice(8,"Sure!");
            CSN_ResumeAI();
          }
          FSM(7){
            CSN_SuspendAI();
            CSN_PlayerTellActor("No way, I see what you are getting at!");
            CSN_PlayerTellActor("You are just trying to make my fall off like an idiot!");
            CSN_Delay(1);
            CSN_ActorTellPlayer("Fine! I am going to find it myself.");
            CSN_ActorTellPlayer("When I find it I am not gonna tell you!");
            CSN_ResumeAI();
            FSM_State=0;
          }
          FSM(8){
            CSN_SuspendAI();
            CSN_PlayerTellActor("Sure!");
            CSN_ActorTellPlayer("Cooool! Let's get started!");
            CSN_ResumeAI();
            FSM_State=9;
          }
          FSM(9){
            Say("You found it yet?");
          }
          
          SCM("Cutscene");
        }EndEffect; 
      }
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          CSN_ResumeAI();
          FSM(5){
            FSM_State=6;
          }
          Say("oowah!");
        }EndEffect;
      }
    }

    NPC("Timmy"){
      CharModel = "Player";
      Pos = <-2,0,-3>;
      MGAvailable = "ALL";
      AI = "Revenge"|"TileBound"|"Help"|"Wander";
      RespawnPolicy = "OnSpot";
      Equip("Shield");
    }
    NPC("The Condemned"){
      CharModel = "grunt";
      SpawnOnRandTile();
      MGAvailable = "Defender"|"Endurance"|"Alertness";
      AI = AI = "Aggro"|"Wander"|"TileBound";
      RespawnPolicy = "OnSpot";
      Equip("Shield");
      Equip("Sword");
    }
    NPC("The Cursed"){
      CharModel = "sorcerer";
      SpawnOnRandTile();
      MGAvailable = "Defender"|"Wizardry"|"Alertness";
      AI = AI = "Skirmish"|"Aggro"|"Wander"|"TileBound";
      RespawnPolicy = "OnSpot";
      Equip("Shield");
    }
    NPC("The Innocent"){
      CharModel = "ghoul";
      SpawnOnRandTile();
      MGAvailable ="ALL";
      AI = "Revenge"|"TileBound";
      RespawnPolicy = "OnSpot";
      Equip("Shield");
      AgentTrigger("FSM"){
        Condition="Clicked";
        EffectBegin{
          CSN_Clear();
          FSM(0){
            CSN_SuspendAI();
            CSN_ActorPrompt("How may I help you?");
            CSN_Choice(1,"Sell Equipments");
            CSN_Choice(1,"Buy Equipments");
            
            CSN_ResumeAI();
          }
          FSM(1){
            CSN_SuspendAI();
            CSN_ActorTellPlayer("Huh? You think that I am a dealer of some sort?");
            CSN_Delay(1);
            CSN_ActorTellPlayer("Well, I am not. Nice try though.");
            CSN_ActorTellPlayer("Watch your back, dude.");
            CSN_ResumeAI();
            FSM_State=0;
          }


          SCM("Cutscene");
        }EndEffect;
      }
    }

  }EndEffect;
}
