Trigger("Initialization"){
  Condition = "True";

  EffectBegin{

    NPC(""){
      CharModel = "Warden";
      Pos = <6,-2,-6>;
      MGAvailable = "ALL";
      AI = "Wander"|"Aggro"|"TileBound";
      Equip("Shield");
      Equip("Sword");
      RespawnPolicy = "StayDead";
    }

    CutScene(" "){
      Clear();

      AddFrame();Flag="YieldAI"|"Skippable";Event="LookAtActor"|"MoveLightToActor";
      ActorSelf();
      CamZoom=4;CamPhi=0.4;CamTheta=2.4;
      Text("Welcome to the prototype scenario...");
      Pause();
      
      AddFrame();Flag="YieldAI"|"Skippable";Event="LookAtActor"|"MoveLightToActor";
      ActorSelf();CamZoom=4;CamPhi=0.4;CamTheta=2.4;
      Text("In this scenario, your objective is to defeat the warden");
      Pause();


      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      Actor("Warden");
      FaceActor2();Actor2Self();
      ActorSay("Kido, come on down here!");
      ActorMove("Shieldbash");
      Pause();
  
      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      ActorSay("Let's get started with jumping and dodging!");
      Timer = 2;


      AddFrame();Actor("Warden");Event="LookAtActor"|"MoveLightToActor";
      Timer = 1;

    }
    SetScreenMode("Cutscene");
    RemoveThisTrigger();

  }EndEffect;
}
Trigger("VictoryCondition"){
  Condition = "NumNPCAliveEqI1"; I1=0;
  
  EffectBegin{
    CutScene(""){
      Clear();

      AddFrame();Flag="YieldAI";Event="LookAtActor";
      Actor("Warden");ActorMove("Stand");
      CamZoom=1;CamTheta=-1.4;CamPhi=-0.1;
      ActorSay("O");
      Timer = 1;

      AddFrame();Flag="YieldAI";Event="LookAtActor";
      ActorSay("M");
      Timer = 1;

      AddFrame();Flag="YieldAI";Event="LookAtActor";
      ActorSay("G");
      Timer = 1;

      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSay("You won't be as lucky...");
      Pause();

      AddFrame();
      ActorSay("...next time...");CamZoom=4;
      Timer = 2;

      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSay("(hmm... this kid has some potential...)");
      Pause();

      AddFrame();
      Text("You have completed this scenario!");
      Pause();

    }
    SetScreenMode("Cutscene");
    AwardSkill("Defender");
    RemoveThisTrigger();

  }EndEffect;
}
