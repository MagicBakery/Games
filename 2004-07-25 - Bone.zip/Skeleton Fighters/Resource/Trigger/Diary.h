Trigger("Initialization"){
  Condition = "True";

  EffectBegin{

    NPC("Mary"){
      CharModel = "warden";
      Pos = <3,0,3>;
      MGAvailable = "ALL";
      AI = "Flee";
      RespawnPolicy = "OnSpot";
      AgentTrigger("Attacked"){
        Condition="Attacked";
        EffectBegin{
          Say("!!");
        }EndEffect; 
      }
      AgentTrigger("Clicked"){
        Condition="Clicked";
        EffectBegin{
          Say("?");
          RemoveThisTrigger();
        }EndEffect;
      }
    }
    NPC("Timmy"){
      CharModel = "player";
      Pos = <8,0,6>;
      MGAvailable = "ALL";
      AI = "Skirmish"|"Aggro";
      Equip("Shield");
      RespawnPolicy = "OnSpot";
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          R1++;
          if(R1==2){
            Say("Damn it...");
          }
          if(R1==1){
            Say("Catch, Bill!");
            SelectNPC("Billy");
            ActorSay("I got it!");
          }
        }EndEffect; 
      }
      AgentTrigger("Respawn"){
        Condition="Respawn";
        EffectBegin{ 
          R1--; 
          Say("Yeeha!");
        }EndEffect; 
      }
    }
    NPC("Billy"){
      CharModel = "player";
      Pos = <6,0,8>;
      MGAvailable = "ALL";
      AI = "Skirmish"|"Aggro"|"Jump";
      Equip("Sword");
      RespawnPolicy = "OnSpot";
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          R1++;
          if(R1==2){
            Say("oowah!");
          }
          if(R1==1){
            Say("It's all yours, Tim!");
            SelectNPC("Timmy");
            ActorSay("Alright!");
          }
        }EndEffect; 
      }
      AgentTrigger("Respawn"){
        Condition="Respawn";
        EffectBegin{ 
          R1--; 
          Say("I'm back!");
        }EndEffect; 
      }
    }
    

    CutScene(" "){
      Clear();

      AddFrame();Flag="YieldAI"|"Skippable";
      ActorSelf();Event="LookAtActor"|"MoveLightToActor";
      CamZoom=1;CamPhi=0.1;CamTheta=-1.9;
      Pause();

      AddFrame();Flag="YieldAI"|"Skippable"|"YieldCam";
      Actor("Billy");Actor2("Mary");FaceActor2();
      ActorMove("Laugh");
      Timer =0;

      AddFrame();Flag="YieldAI"|"Skippable"|"YieldCam";
      Actor("Timmy");Actor2("Billy");FaceActor2();
      ActorMove("Laugh");
      Timer =0;
      
      AddFrame();Flag="YieldAI"|"Skippable";Event="LookAtActor"|"MoveLightToActor";
      Actor("Mary");FaceActor2();Actor2Self();
      ActorSay("um...excuse me...");
      Pause();

      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSelf();Actor2("Mary");FaceActor2();
      ActorSay("Yes?");
      ActorMove("Standup");
      Pause();
      
      AddFrame();Flag="YieldAI";
      Actor("Mary");Event="LookAtActor"|"MoveLightToActor";
      ActorSay("My brothers have stolen my diary,");
      Pause();

      AddFrame();Flag="YieldAI";
      Actor("Mary");Event="LookAtActor"|"MoveLightToActor";
      ActorSay("Would you get it back for me?");
      Pause();
  
      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSelf();
      ActorSay("Sure!");
      Pause();

      AddFrame();Flag="YieldAI"|"YieldCam";
      Actor("Mary"); ActorSay("Thank you so much!");
      Pause();

      AddFrame();
      Actor("Mary");Actor2("Billy");FaceActor2();
      ActorSay("Watch out! There they are!");CamZoom=12;CamPhi=0.2;
      Timer = 1;
      
      
    }
    SetScreenMode("Cutscene");
    RemoveThisTrigger();

  }EndEffect;
}
//------------------------------------------------------------------------------------------------
Trigger("VictoryCondition"){
  Condition = "R1EqI1"; I1=2;
  
  EffectBegin{
    CutScene(""){
      Clear();
      
      AddFrame();Flag="YieldAI";
      ActorSelf();ActorMove("Stand");
      ActorSay("(That wasn't too bad, I guess...)");
      Pause();


      AddFrame();Flag="YieldAI";
      Actor("Timmy");ActorTeleport=<8,0,6>;
      Timer = 0;
      AddFrame();Flag="YieldAI";
      Actor("Billy");ActorTeleport=<6,0,8>;
      Timer = 0;

      AddFrame();Flag="YieldAI";
      Actor("Mary");ActorTeleport=<3,0,3>;
      Timer = 0;

      AddFrame();Flag="YieldAI";
      ActorSelf();ActorTeleport=<1,0,1>;
      Timer = 0;

      AddFrame();Flag="YieldAI";
      Event("MoveLightToActor");
      ActorSelf();Actor2("Mary");FaceActor2();
      Timer=0.5;

      AddFrame();Flag="YieldAI";
      Event="LookAtActor"|"MoveLightToActor";
      CamZoom=0.8;CamPhi=0.3;CamTheta=1.4;
      ActorSelf();Actor2("Mary");FaceActor2();
      ActorSay("Mary, I've got your diary!");
      Pause();

      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      Actor("Mary");Actor2Self();FaceActor2();Flag("YieldCam");
      ActorSay("Ooo Thank you soooo much! <3");
      ActorMove("Jump");
      Pause();

      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      Actor("Mary");Actor2Self();FaceActor2();
      ActorMove("Stand");
      ActorSay("Well, I wish I can give you something as a reward,...");
      Pause();

      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      ActorSay("...but the only thing I have is this diary.");
      Pause();

      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSelf();ActorSay("...");
      Pause();

      AddFrame();Flag="YieldAI"|"YieldCam";
      ActorSelf();ActorSay("Hmm...That's too bad, I guess I'll have to keep it then...");
      Pause();

      AddFrame();Flag="YieldAI";Event="LookAtActor"|"MoveLightToActor";
      Actor("Mary");ActorSay("WWWHHHAAATTT ??!!!");CamZoom=0.8;CamPhi=-0.2;
      Pause();

      AddFrame();Flag="YieldCam";
      ActorSay("GIVE IT BACK, YOU JERK!!!!");CamZoom=8;CamPhi=0.2;
      ActorAI="Wander"|"Aggro";
      Timer=1;

    }
    SetScreenMode("Cutscene");
    AwardSkill("Alertness");
    SelectNPC("Mary");
    RemoveAgentTrigger("Attacked");
    RemoveAgentTrigger("Clicked");
    SelectNPC("Timmy");
    RemoveAgentTrigger("Defeated");
    RemoveAgentTrigger("Respawn");
    SelectNPC("Billy");
    RemoveAgentTrigger("Defeated");
    RemoveAgentTrigger("Respawn");
    RemoveThisTrigger();

  }EndEffect;
}
