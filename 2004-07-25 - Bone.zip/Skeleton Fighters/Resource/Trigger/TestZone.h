Trigger("Initialization"){
  Condition = "True";

  EffectBegin{

    NPC("Mike"){
      CharModel = "grunt";
      SpawnOnRandTile();
      MGAvailable = "ALL";
      AI = "Wander"|"Aggro"|"TileBound";
      Equip("Great Katana");
      RespawnPolicy = "StayDead";
    }
    NPC("Nick"){
      CharModel = "grunt";
      SpawnOnRandTile();
      MGAvailable = "ALL";
      AI = "Wander"|"Aggro"|"TileBound";
      Equip("Great Katana");
      RespawnPolicy = "StayDead";
    }
    
  }EndEffect;
}
