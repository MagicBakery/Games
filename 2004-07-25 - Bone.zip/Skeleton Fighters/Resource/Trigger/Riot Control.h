Trigger("Initialization"){
  Condition = "True";

  EffectBegin{
    NPC("The Condemned"){
      CharModel = "grunt";
      SpawnOnRandTile();
      MGAvailable = "Defender"|"Endurance"|"Alertness";
      AI = "Aggro"|"Wander"|"Help";
      //Equip("Shield");
      //Equip("Sword");
      Equip("Great Katana");
      RespawnPolicy = "RandomSameAIEq";
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          R1++;
        }EndEffect; 
      }
    }
    NPC("The Cursed"){
      CharModel = "sorcerer";
      SpawnOnRandTile();
      MGAvailable = "Defender"|"Wizardry"|"Alertness";
      AI = "Aggro"|"Wander"|"Help"|"CallForHelp";
      Equip("Shield");
      RespawnPolicy = "RandomSameAIEq";
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          R1++;
        }EndEffect; 
      }
    }
    NPC("The Innocent"){
      CharModel = "ghoul";
      SpawnOnRandTile();
      MGAvailable = "ALL";
      AI = "Revenge"|"Wander"|"CallForHelp";
      RespawnPolicy = "RandomSameAIEq";
      Equip("Sword");
      AgentTrigger("Defeated"){
        Condition="Defeated";
        EffectBegin{
          R1++;
        }EndEffect; 
      }
    }
    

    CutScene(" "){
      Clear();

      AddFrame();Flag="YieldAI"|"Skippable";
      ActorSelf();Event="LookAtActor"|"MoveLightToActor";
      CamZoom=4;CamPhi=0.1;CamTheta=-1.9;
      Pause();

      AddFrame();Flag="YieldAI"|"Skippable"|"YieldCam";
      ActorSelf();
      Actor2("The Condemned");FaceActor2();
      Timer = 1;

      AddFrame();Flag="YieldAI"|"Skippable";
      Actor("The Condemned");
      Actor2Self();FaceActor2();Event="LookAtActor"|"MoveLightToActor";
      ActorMove("Attack");
      ActorSay("So the warden thinks you can take care of us?");
      Pause();

      AddFrame();Flag="YieldAI"|"Skippable"|"YieldCam";
      ActorSelf();
      Actor2("The Cursed");FaceActor2();
      Timer = 1;

      AddFrame();Flag="YieldAI"|"Skippable";
      Actor("The Cursed");Event="LookAtActor"|"MoveLightToActor";
      Actor2Self();FaceActor2();
      ActorMove("Laugh");SFX = "Laugh";
      ActorSay("We'll show you who's boss, MUAHAHAHAHAH!!!");
      Pause();

      AddFrame(); Flag="YieldAI"|"Skippable";
      ActorSelf();Event="LookAtActor"|"MoveLightToActor";
      Text("OBJECTIVE: Show the warden that you have it under control when he comes back in 5 minutes!");
      Pause();
      
    }
    SetScreenMode("Cutscene");

    CountDownTimer=300;
    ShowT1("Time Remaining: ");
    ShowR1("Inmates Defeated: ");
    ShowMiniMap();

    RemoveThisTrigger();

  }EndEffect;
}
//------------------------------------------------------------------------------------------------
Trigger("VictoryCondition"){
  Condition = "TimerExpired";
  
  EffectBegin{
    ClearActors();
    AddActor("Warden");Equip("Shield");Equip("Sword");

    CutScene(""){
      Clear();
    }

    if(R1 > 17){
      AwardSkill("Berserk");
      AwardSkill("Endurance");
      CutScene(""){
        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Actor("The Condemned");ActorMove("Death");
        ActorTeleport=<5,0,7>;
        Timer=0;

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Actor("The Cursed");ActorMove("Death");
        ActorTeleport=<6,0,6>;
        Timer=0;
      
        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Actor("The Innocent");ActorMove("Death");
        ActorTeleport=<7,0,5>;
        Timer=0;

        AddFrame();Flag="YieldAI"|"ProcessActor";
        Actor("Warden");ActorTeleport=<3,0,3>;
        ActorMove("Stand");
        Timer=0;

        AddFrame();Flag="YieldAI"|"ProcessActor";
        Actor2Self();FaceActor2();
        ActorSay("I'm back!");
        Pause();

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Event="LookAtActor"|"MoveLightToActor";
        CamZoom=0.8;CamPhi=0.2;CamTheta=2.2;
        ActorSelf();ActorTeleport=<1,0,1>;
        Actor2("Warden");FaceActor2();
        ActorMove("Stand");
        Timer=1;

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Event="LookAtActor"|"MoveLightToActor";
        Actor("Warden");
        Actor2("The Condemned");FaceActor2();
        ActorSay("OMG what have you done to them?");
        Pause();  

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        ActorSelf();ActorSay("Not my fault, they asked for it.");
        Pause();  

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Actor("Warden");Actor2Self();FaceActor2();
        ActorSay("You are a devil...");
        Pause();  

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Text("(You have achieved the toughest ending of this mission!)");
        Pause();

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Text("(This mission now ends.)");
        Pause();
      }
      SetScreenMode("Cutscene");
      RemoveThisTrigger();
      return;
    }

    CutScene(""){
  
      AddFrame();Flag="YieldAI"|"ProcessActor";
      Actor("Warden");ActorTeleport=<3,0,3>;
      ActorMove("Stand");
      Timer=0;

      AddFrame();Flag="YieldAI"|"ProcessActor";
      Actor2Self();FaceActor2();
      ActorSay("I'm back!");
      Pause();

      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Actor("The Condemned");ActorTeleport=<5,0,7>;
      ActorMove("Stand");
      Timer=0;

      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Actor("The Cursed");ActorTeleport=<6,0,6>;
      ActorMove("Stand");
      Timer=0;
      
      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Actor("The Innocent");ActorTeleport=<7,0,5>;
      ActorMove("Stand");
      Timer=0;

      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Event="LookAtActor"|"MoveLightToActor";
      CamZoom=0.8;CamPhi=0.2;CamTheta=2.2;
      ActorSelf();ActorTeleport=<1,0,1>;
      Actor2("Warden");FaceActor2();
      ActorMove("Stand");
      Timer=1;
    }

    if(R1 > 7){
      AwardSkill("Endurance");
      CutScene(""){
        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Event="LookAtActor"|"MoveLightToActor";
        Actor("Warden");
        Actor2Self();FaceActor2();
        ActorSay("I see you have it under control, I knew I can count on you!");
        ActorMove("EqWaist");
        Pause();  

        AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
        Text("(You have achieved the normal ending of this mission. This mission now ends.)");
        Pause();
      }
      SetScreenMode("Cutscene");
      RemoveThisTrigger();
      return;
    }
    CutScene(""){
      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Event="LookAtActor"|"MoveLightToActor";
      Actor("The Cursed");
      Actor2Self();FaceActor2();
      ActorMove("Laugh");
      ActorSay("Yes, hide behind the warden. That's all you can do, MWAHAHAHHA!!!");
      Pause();

      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Event="LookAtActor"|"MoveLightToActor";
      Actor("Warden");
      Actor2Self();FaceActor2();
      ActorSay("Don't worry, I will take care of them... You are free to go.");
      Pause();  
      
      AddFrame();Flag="YieldAI"|"ProcessActor"|"YieldCam";
      Text("(You have failed to defeat enough enemies. This mission now ends.)");
      Pause();  
    }

    SetScreenMode("Cutscene");
    RemoveThisTrigger();
    return;

  }EndEffect;
}
