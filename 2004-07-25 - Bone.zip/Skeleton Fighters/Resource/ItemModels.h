ItemModel("Shield"){
  Flags="EqShield";
  Mesh="Shield";
}
ItemModel("Sword"){
  Flags="EqSword"|"EqWaist";
  Mesh="Sword";
}
ItemModel("Great Sword"){
  Flags="EqSword"|"EqBack"|"GreatSword";
  Mesh="Great Sword";
}
ItemModel("Katana"){
  Flags="EqSword"|"EqWaist";
  Mesh="Katana";
}
ItemModel("Great Katana"){
  Flags="EqSword"|"EqBack"|"GreatKatana";
  Mesh="Great Katana";
}