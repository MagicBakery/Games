// Config.FF
Version = "Version 2004-07-25";


/*/ // High Resolution 
Windowed = 0;
WndWidth = 1024;
WndHeight= 768;
D3DWidth = 1024;
D3DHeight= 768;


/*/ // Medium Resolution
Windowed = 1;
WndWidth = 640;
WndHeight= 480;
D3DWidth = 640;
D3DHeight= 480;
//*/

/*/ // Low Resolution
Windowed = 0;
WndWidth = 320;
WndHeight= 240;
D3DWidth = 320;
D3DHeight= 240;
//*/