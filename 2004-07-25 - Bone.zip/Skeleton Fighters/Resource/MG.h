MetaGear("Alertness"){
  Icon = "MG_Conscious";
  Desc = "Increases eye sight and\nallows you to see enemy status";
  ID = 0x00000040;
  SP = 1;
}
MetaGear("Endurance"){  
  Icon = "MG_Endurance";  
  Desc = "Increases stamina reserve and\nregen, and reduces trauma when attacked";  
  ID = 0x00000004;  
  SP = 1
}
MetaGear("Defender"){
  Icon = "MG_Defend";
  Desc = "Lowers impact on shield and\nlets you walk with shield up";
  ID = 0x00000020;
  SP = 1;
}
MetaGear("Swordsmanship"){  
  Icon = "MG_Swordsman";  
  Desc = "Increases attack speed and\nallows you to parry";  
  ID = 0x00000010;  
  SP = 2;
}
MetaGear("Wizardry"){
  Icon = "MG_Wizardry";
  Desc = "Increases casting speed,\nMP reserve and regeneration";
  ID = 0x00000080;
  SP = 2;
}
MetaGear("Meditate"){
  Icon="MG_Meditation";
  Desc="Increases HP reserve and regen, and\ndefense against fire elemental damage";  
  ID  = 0x00000002;  
  SP  = 3;
}
MetaGear("Consume"){
  Icon = "MG_Consume";
  Desc = "Allows you to cast magic using\nstamina and hp when you are out of mp";
  ID = 0x00000100;
  SP = 2;
}
MetaGear("Berserk"){
  Icon = "MG_Berserk";
  Desc = "Sacrifice stamina for physical damage\nand increases fire elemental damage";
  ID = 0x00000008;
  SP = 5;
}
