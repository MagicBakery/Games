CharModel("player"){
  AgentModel="Skeleton";
  ATKBase    = 1;
  HPBase     = 55;
  MPBase     = 15;
  SPBase     = 3;
  STBase     = 20;
}
CharModel("warden"){
  AgentModel = "Skeleton";
  ATKBase    = 4;
  HPBase     = 55;
  MPBase     = 50 ;
  SPBase     = 3;
  STBase     = 20;
}
CharModel("ghoul"){
  AgentModel = "Skeleton";
  ATKBase    = 1;
  HPBase     = 25;
  MPBase     = 0;
  SPBase     = 4;
  STBase     = 10;
}
CharModel("grunt"){
  AgentModel = "Skeleton";
  ATKBase    = 1;
  HPBase     = 55;
  MPBase     = 0;
  SPBase     = 4;
  STBase     = 20;
}
CharModel("sorcerer"){
  AgentModel = "Skeleton";
  ATKBase    = 1;
  HPBase     = 25;
  MPBase     = 40;
  SPBase     = 5;
  STBase     = 3;
}
